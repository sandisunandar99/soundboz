package embedlit
