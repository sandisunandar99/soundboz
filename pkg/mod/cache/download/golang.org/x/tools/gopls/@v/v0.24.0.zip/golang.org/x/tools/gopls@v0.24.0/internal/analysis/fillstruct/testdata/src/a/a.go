// Copyright 2020 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package fillstruct

import (
	"b"
	"go/ast"
	"go/token"
	"unsafe"
)

type emptyStruct struct{}

var _ = emptyStruct{}

type basicStruct struct {
	foo int
}

var _ = basicStruct{} // want `basicStruct literal has missing fields`

type twoArgStruct struct {
	foo int
	bar string
}

var _ = twoArgStruct{} // want `twoArgStruct literal has missing fields`

var _ = twoArgStruct{ // want `twoArgStruct literal has missing fields`
	bar: "bar",
}

type nestedStruct struct {
	bar   string
	basic basicStruct
}

var _ = nestedStruct{} // want `nestedStruct literal has missing fields`

var _ = b.B{} // want `b.B literal has missing fields`

var _ = b.B{ExportedInt: 0}

type typedStruct struct {
	m  map[string]int
	s  []int
	c  chan int
	c1 <-chan int
	a  [2]string
}

var _ = typedStruct{} // want `typedStruct literal has missing fields`

type funStruct struct {
	fn func(i int) int
}

var _ = funStruct{} // want `funStruct literal has missing fields`

type funStructComplex struct {
	fn func(i int, s string) (string, int)
}

var _ = funStructComplex{} // want `funStructComplex literal has missing fields`

type funStructEmpty struct {
	fn func()
}

var _ = funStructEmpty{} // want `funStructEmpty literal has missing fields`

type Foo struct {
	A int
}

type Bar struct {
	X *Foo
	Y *Foo
}

var _ = Bar{} // want `Bar literal has missing fields`

type importedStruct struct {
	m  map[*ast.CompositeLit]ast.Field
	s  []ast.BadExpr
	a  [3]token.Token
	c  chan ast.EmptyStmt
	fn func(ast_decl ast.DeclStmt) ast.Ellipsis
	st ast.CompositeLit
}

var _ = importedStruct{} // want `importedStruct literal has missing fields`

type pointerBuiltinStruct struct {
	b *bool
	s *string
	i *int
}

var _ = pointerBuiltinStruct{} // want `pointerBuiltinStruct literal has missing fields`

var _ = []ast.BasicLit{
	{}, // want `ast.BasicLit literal has missing fields`
}

var _ = []ast.BasicLit{{}} // want "ast.BasicLit literal has missing fields"

type unsafeStruct struct {
	foo unsafe.Pointer
}

var _ = unsafeStruct{} // want `unsafeStruct literal has missing fields`

type inner struct {
	bar int
}

type outer struct {
	inner inner
	foo   int
}

var _ = outer{ // want `outer literal has missing fields`
	inner: inner{} // want `inner literal has missing fields`
}

type untagged struct {
	A, B string
}

// no diagnostic expected (contains untagged elements)
var _ = untagged{"a"}

// Tests for issue 71815: recursive pointer types and non-composite pointer fields.
type P *P

type recursivePtrStruct struct {
	p  P
	pp *P
}

var _ = recursivePtrStruct{} // want `recursivePtrStruct literal has missing fields`

type doublePtrStruct struct {
	x **int
	c *chan int
}

var _ = doublePtrStruct{} // want `doublePtrStruct literal has missing fields`

// Tests for issue 71815: pointer to array, slice, map (composite literal types).
type ptrCompositeStruct struct {
	arr *[3]int
	slc *[]int
	mp  *map[string]int
}

var _ = ptrCompositeStruct{} // want `ptrCompositeStruct literal has missing fields`

// Tests for issue 71815: pointer to interface.
type ptrInterfaceStruct struct {
	iface *interface{ m() }
	a     *any
}

var _ = ptrInterfaceStruct{} // want `ptrInterfaceStruct literal has missing fields`