module golang.org/x/vuln

go 1.26.0

require (
	github.com/google/go-cmdtest v0.4.1-0.20220921163831-55ab3332a786
	github.com/google/go-cmp v0.6.0
	golang.org/x/mod v0.41.0
	golang.org/x/sync v0.23.0
	golang.org/x/telemetry v0.0.0-20260908163034-4bcc4b2ee518
	golang.org/x/tools v0.50.0
	golang.org/x/tools/go/packages/packagestest v0.1.1-deprecated
)

require (
	github.com/google/renameio v0.1.0 // indirect
	golang.org/x/sys v0.48.0 // indirect
	golang.org/x/tools/go/expect v0.1.1-deprecated // indirect
)
